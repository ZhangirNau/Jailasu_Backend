# ProjectJailasu/backend/main.py
# uvicorn ProjectJailasu.backend.main:app --reload
# ngrok http 8000
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import logging
import os

from ProjectJailasu.backend.routers import webhook, auth  # Later: auth, places, booking

app = FastAPI(title="Jailasu API", version="1.0.0")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("jailasu-backend")


@app.on_event("startup")
def on_startup():
    """Создаём папку для данных (если потребуется)"""
    os.makedirs("ProjectJailasu/backend/data", exist_ok=True)
    logger.info(" Jailasu backend started")


# ---------------- CORS ----------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # В проде указать домен Tilda
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------- ROUTERS ----------------
app.include_router(webhook.router, prefix="/api", tags=["webhook"])
# Будет добавлено:
app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
# app.include_router(places.router, prefix="/api/places", tags=["places"])
# app.include_router(booking.router, prefix="/api/booking", tags=["booking"])


# ---------------- ROOT ----------------
@app.get("/")
def home():
    return {"status": "running", "message": "Backend connected to PostgreSQL ✅"}
