# ProjectJailasu/backend/models.py

import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Text, ForeignKey, UUID, Float, Boolean, Integer
from sqlalchemy.orm import relationship
from ProjectJailasu.backend.database import Base

# ----------- USERS -----------
class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String)
    surname = Column(String)
    phone = Column(String, nullable=True)
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    bookings = relationship("Booking", back_populates="user")

# ----------- CATEGORIES -----------
class Category(Base):
    __tablename__ = "categories"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String, nullable=False)

    places = relationship("Place", back_populates="category")

# ----------- PLACES (restaurants, saunas etc) -----------
class Place(Base):
    __tablename__ = "places"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    category_id = Column(UUID(as_uuid=True), ForeignKey("categories.id"))
    name = Column(String, nullable=False)
    description = Column(Text)
    address = Column(String)
    phone = Column(String)
    rating = Column(Float, default=0.0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    category = relationship("Category", back_populates="places")
    bookings = relationship("Booking", back_populates="place")

# ----------- BOOKINGS -----------
class Booking(Base):
    __tablename__ = "bookings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    place_id = Column(UUID(as_uuid=True), ForeignKey("places.id"))
    booking_time = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    status = Column(String, default="pending")   # pending, confirmed, cancelled

    user = relationship("User", back_populates="bookings")
    place = relationship("Place", back_populates="bookings")

# ----------- REVIEWS -----------
class Review(Base):
    __tablename__ = "reviews"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    place_id = Column(UUID(as_uuid=True), ForeignKey("places.id"))
    rating = Column(Integer, nullable=False)
    comment = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

# -------- OPTIONAL: LOGS FOR WEBHOOKS ----------
class WebhookLog(Base):
    __tablename__ = "webhook_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_type = Column(String(50), nullable=False)
    payload = Column(Text, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
