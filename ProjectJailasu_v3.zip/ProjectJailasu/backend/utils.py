from passlib.context import CryptContext

# bcrypt security context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    """
    Хэшируем пароль, режем до 72 символов (ограничение bcrypt)
    """
    if not password:
        raise ValueError("Password is required")

    password = password[:72]  # Ограничение bcrypt
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Проверяем пароль, с учётом ограничения bcrypt
    """
    plain_password = plain_password[:72]
    return pwd_context.verify(plain_password, hashed_password)
