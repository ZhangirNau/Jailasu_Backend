# ProjectJailasu/backend/routers/auth.py

from fastapi import (
    APIRouter, Depends, HTTPException, status,
    Request, Form
)
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from jose import JWTError, jwt
from uuid import UUID
from pydantic import BaseModel
from typing import Optional
import os

from ProjectJailasu.backend.database import get_db
from ProjectJailasu.backend import models
from ProjectJailasu.backend.utils import hash_password, verify_password

router = APIRouter(prefix="/api/auth", tags=["auth"])

# ---------------------------------------------------------
# JWT CONFIG
# ---------------------------------------------------------
SECRET_KEY = os.getenv("JWT_SECRET", "devsecretkey!!change!!")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24 часа

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


# ---------------------------------------------------------
# SCHEMAS
# ---------------------------------------------------------
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    id: UUID
    name: str
    surname: Optional[str] = None
    email: str
    phone: Optional[str] = None

    class Config:
        from_attributes = True


# ---------------------------------------------------------
# JWT Helpers
# ---------------------------------------------------------
def create_access_token(data: dict):
    """Создаёт JWT токен"""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

security = HTTPBearer()

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security), db: Session = Depends(get_db)):
    """Получаем текущего пользователя из JWT токена"""
    token = credentials.credentials  # сам токен без 'Bearer '
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise HTTPException(status_code=401, detail="Invalid token")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

    user = db.query(models.User).filter(models.User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return user



# ---------------------------------------------------------
# ROUTES
# ---------------------------------------------------------
@router.post("/register", response_model=UserOut)
async def register(
    request: Request,
    db: Session = Depends(get_db),
    name: str = Form(None),
    surname: str = Form(None),
    email: str = Form(None),
    password: str = Form(None),
):
    """
    Регистрация нового пользователя
    Работает как с form-data (Тильда), так и с JSON
    """
    if not email:  # если данные пришли в JSON
        data = await request.json()
        name = data.get("name")
        surname = data.get("surname")
        email = data.get("email")
        password = data.get("password")

    existing = db.query(models.User).filter(models.User.email == email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    user = models.User(
        name=name,
        surname=surname,
        email=email,
        password_hash=hash_password(password),
        created_at=datetime.utcnow()
    )

    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.post("/login", response_model=Token)
async def login(
    request: Request,
    db: Session = Depends(get_db),
    username: str = Form(None),
    password: str = Form(None)
):
    """
    Авторизация пользователя
    Работает с form-data (OAuth2 / Тильда) и JSON
    """
    if not username:  # если запрос JSON, а не form-data
        data = await request.json()
        username = data.get("email")
        password = data.get("password")

    user = db.query(models.User).filter(models.User.email == username).first()

    if not user:
        raise HTTPException(status_code=400, detail="User not found")

    if not verify_password(password, user.password_hash):
        raise HTTPException(status_code=400, detail="Incorrect password")

    token = create_access_token({"sub": user.email})
    return {"access_token": token, "token_type": "bearer"}


@router.get("/me", response_model=UserOut)
def get_me(current_user: models.User = Depends(get_current_user)):
    """Возвращает информацию о текущем пользователе"""
    return current_user
