# contact.py
from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, EmailStr
from sqlalchemy.orm import Session
from ProjectJailasu.backend import models, schemas
from ProjectJailasu.backend.database import get_db

router = APIRouter()

# ------------------ Обычная форма контакта ------------------
class ContactMessage(BaseModel):
    name: str
    email: EmailStr
    message: str

# Временное хранилище (если нет базы)
contact_messages = []

@router.post("/contact")
async def send_contact_message(data: ContactMessage):
    contact_messages.append({
        "name": data.name,
        "email": data.email,
        "message": data.message
    })
    return {"success": True, "message": "Сообщение успешно отправлено"}


# ------------------ Webhook от Tilda ------------------
@router.post("/tilda-webhook")
async def receive_tilda_form(form_data: schemas.ContactMessage, db: Session = Depends(get_db)):
    # Проверяем, существует ли пользователь
    user = db.query(models.User).filter(models.User.email == form_data.email).first()

    if not user:
        user = models.User(
            name=form_data.name,
            email=form_data.email,
            phone=None
        )
        db.add(user)
        db.commit()
        db.refresh(user)

    # Сохраняем заявку
    new_form = models.FormSubmission(
        user_id=user.id,
        form_name="Tilda Form",
        message=form_data.message
    )
    db.add(new_form)

    # Логируем webhook
    log = models.WebhookLog(
        event_type="Tilda submission",
        payload=form_data.json()
    )
    db.add(log)

    db.commit()
    db.refresh(new_form)
    db.refresh(log)

    return {"status": "ok", "form_id": new_form.id, "user": user.email}


# ------------------ Тестовые эндпоинты ------------------
@router.get("/forms")
def get_forms(db: Session = Depends(get_db)):
    return db.query(models.FormSubmission).all()

@router.get("/logs")
def get_logs(db: Session = Depends(get_db)):
    return db.query(models.WebhookLog).all()

@router.get("/health")
def health_check():
    return {"status": "API is running"}
