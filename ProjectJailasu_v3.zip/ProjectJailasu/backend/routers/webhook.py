# ProjectJailasu/backend/routers/webhook.py

from fastapi import APIRouter, Request, Depends
from sqlalchemy.orm import Session
from datetime import datetime
from ProjectJailasu.backend.database import get_db
from ProjectJailasu.backend import models
from ProjectJailasu.backend.utils import hash_password, verify_password
import json
import logging

router = APIRouter()
logger = logging.getLogger("webhook")


@router.post("/webhook")
async def receive_webhook(request: Request, db: Session = Depends(get_db)):
    """
    Универсальный приём данных от форм Tilda.
    Автоматически обрабатывает формы: обратной связи, регистрации, логина и регистрации объекта.
    """
    try:
        content_type = request.headers.get("content-type", "")
        payload = {}

        # --- Принимаем данные ---
        if "application/x-www-form-urlencoded" in content_type or "multipart/form-data" in content_type:
            form_data = await request.form()
            payload = dict(form_data)
        elif "application/json" in content_type:
            payload = await request.json()

        form_name = payload.get("formname", "unknown")
        logger.info(f" Received webhook from Tilda | form: {form_name} | data: {payload}")


        if form_name == "contact_form":
            log = models.WebhookLog(
                event_type="contact_form",
                payload=json.dumps(payload, ensure_ascii=False),
                timestamp=datetime.utcnow()
            )
            db.add(log)
            db.commit()
            return {"status": "success", "message": "Contact form received"}


        elif form_name == "register_user":
            name = payload.get("Name") or ""
            surname = payload.get("Surname") or ""
            email = payload.get("Email")
            password = payload.get("Password")

            if not email or not password:
                return {"status": "error", "detail": "Email and password are required"}

            # Проверяем — существует ли уже
            existing = db.query(models.User).filter(models.User.email == email).first()
            if existing:
                return {"status": "error", "detail": "Email already registered"}

            password_hash = hash_password(password)

            user = models.User(
                name=name,
                surname=surname,
                email=email,
                phone=payload.get("Phone"),
                password_hash=password_hash,
                created_at=datetime.utcnow()
            )

            db.add(user)
            db.commit()

            logger.info(f" Registered new user: {email}")
            return {"status": "success", "detail": "User registered successfully"}


        elif form_name == "login":
            email = payload.get("Email")
            password = payload.get("Password")

            if not email or not password:
                return {"status": "error", "detail": "Email and password are required"}

            user = db.query(models.User).filter(models.User.email == email).first()
            if not user:
                return {"status": "error", "detail": "User not found"}

            if not verify_password(password, user.password_hash):
                return {"status": "error", "detail": "Incorrect password"}

            logger.info(f" Successful login for {email}")
            return {"status": "success", "detail": f"Welcome, {user.name}!"}


        elif form_name == "register_object":
            log = models.WebhookLog(
                event_type="register_object",
                payload=json.dumps(payload, ensure_ascii=False),
                timestamp=datetime.utcnow()
            )
            db.add(log)
            db.commit()
            return {"status": "success", "message": "Object registration received"}


        else:
            log = models.WebhookLog(
                event_type=form_name,
                payload=json.dumps(payload, ensure_ascii=False),
                timestamp=datetime.utcnow()
            )
            db.add(log)
            db.commit()
            logger.warning(f"⚠️ Unknown form type: {form_name}")
            return {"status": "success", "message": f"Unknown form {form_name} logged"}

    except Exception as e:
        db.rollback()
        logger.error(f" Webhook error: {e}")
        return {"status": "error", "detail": str(e)}
    finally:
        db.close()
